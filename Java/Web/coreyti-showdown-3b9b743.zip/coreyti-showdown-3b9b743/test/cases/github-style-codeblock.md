
Define a function in javascript:

```
function MyFunc(a) {
    var s = '`';
}
```

And some HTML

```html
<div>HTML!</div>
```