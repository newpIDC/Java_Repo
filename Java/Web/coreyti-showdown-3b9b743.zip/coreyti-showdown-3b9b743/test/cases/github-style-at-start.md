```
function MyFunc(a) {
    // ...
}
```

That is some code!