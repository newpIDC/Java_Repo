
These HTML5 tags should pass through just fine.

<section>hello</section>
<header>head</header>
<footer>footsies</footer>
<nav>navigation</nav>
<article>read me</article>
<aside>ignore me</aside>

the end