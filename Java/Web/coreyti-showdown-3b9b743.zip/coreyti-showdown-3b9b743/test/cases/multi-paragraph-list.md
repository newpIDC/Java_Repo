
 1.  This is a major bullet point.

    That contains multiple paragraphs.

 2.  And another line