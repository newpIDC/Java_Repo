
 1.  Red
 2.  Green
 3.  Blue