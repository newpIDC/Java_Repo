package org.springframework.batch.sample.common;

public class OutputFileNameListener {

}
